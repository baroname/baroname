/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.dailyproject;

/**
 *
 * @author devao
 */
// Main Class to Demonstrate the System
public class CollegeManagementSystem {
    public static void main(String[] args) {
        // Database Connection (Singleton)
        DatabaseConnection db = DatabaseConnection.getInstance();
        db.connect();

        // Users
        Teacher teacher = new Teacher("Mihiretu Kebede ", "T101", "Software Engineering");
       
        Student student = new Student("Eba Girma ", "S202");
        Admin admin = new Admin("Baro", "A303");
        DepartmentHead deptHead = new DepartmentHead("Getahun", "DH404", "SWE");
          LabAssistant labAssistant = new LabAssistant("Sisay Tadesse", "L505", "Physics Lab");

        // Courses
        Course course1 = new Course("OOP Principles", "CS101", 3);
        Course course2 = new Course("Data Structures", "CS102", 4);

        // Operations
        teacher.assignCourse(course1);
        student.enrollCourse(course1);
        student.viewCourses();
        deptHead.approveCourse(course2);
        admin.manageUser(teacher);
        admin.manageSystemSettings();
         labAssistant.assistInLab();
        labAssistant.viewAssignedLab();

        // Display User Info
        teacher.displayInfo();
        student.displayInfo();
        deptHead.displayInfo();
         labAssistant.displayInfo();
    }
}
