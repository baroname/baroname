/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.dailyproject;

/**
 *
 * @author devao
 */
public class LabAssistant extends User {
    private String assignedLab;

    public LabAssistant(String name, String id, String assignedLab) {
        super(name, id);
        this.assignedLab = assignedLab;
    }

    public void assistInLab() {
        System.out.println("Lab Assistant " + name + " is assisting in the " + assignedLab + " lab.");
    }

    public void viewAssignedLab() {
        System.out.println("Lab Assistant " + name + " is assigned to the " + assignedLab + " lab.");
    }

    @Override
    public void displayInfo() {
        System.out.println("Lab Assistant: " + name + ", ID: " + id + ", Assigned Lab: " + assignedLab);
    }
}
